#include "celllistmodel.h"
#include "puyogameconstants.h"
void celllistmodel::addCellModel(int x,int y,int type) {
    cellmodel* cellModel = new cellmodel(x,y,type);
    this->append(cellModel);
}
bool celllistmodel::judeAddCellModel(cellmodel* cell){
    bool flag = true;
    /* Judge the list whether have this Cell (just judge the position) */
    for (int i = 0; i < this->size(); i++) {
        cellmodel* pTemp = this->at(i);
        if (cell->getX() == pTemp->getX() && cell->getY() == pTemp->getY()) {
            flag = false;
        }
    }

    /* Judge the Cell whether beyond the border */
    if (cell->getX() < 0 || cell->getX() >= 6 || cell->getY() < 0 || cell->getY() >= 12) {
        flag = false;
    }
    return flag;
}

cellmodel* celllistmodel::getCellModel(int index) {
    cellmodel* pTemp = this->at(index);
    return pTemp;
}

cellmodel* celllistmodel::getCellModel(int rx, int ry) {
    if (rx >= 0 && rx < 6 && ry >= 0 && ry < 12) {
        for (int i = 0; i < this->size(); i++) {
            cellmodel* pTemp = this->at(i);
            if (pTemp->getX() == rx && pTemp->getY() == ry) {
                return pTemp;
            }
        }
    }
    return NULL;
}
celllistmodel::~celllistmodel() {
    this->clear();
}
celllistmodel::celllistmodel() {

}
