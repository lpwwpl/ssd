#include "puyogameboxcontroller.h"
void puyogameboxcontroller::clearGrid() {
    for (int i = 0; i < WIDTH_TOTAL; i++) {
        for (int j = 0; j < HEIGHT_TOTAL; j++) {
            boxGird[i][j] = -1;
        }
    }
}
void puyogameboxcontroller::removeCellModelFromPuyo() {
    for (int i = 0; i < this->getPl_RealRemoveList()->size(); i++) {
        cellmodel* p = this->getPl_RealRemoveList()->getCellModel(i);
        boxGird[p->getX()][p->getY()] = -1;
    }
    this->getPl_RealRemoveList()->clear();

    this->resetBox();
}
void puyogameboxcontroller::checkBox() {
    for (int i = 0; i < WIDTH_TOTAL; i++) {
        for (int j = 0; j < HEIGHT_TOTAL; j++) {
            if (boxGird[i][j] != -1) {
                this->checkCellModel(new cellmodel(i, j));
            }
        }
    }
}
void puyogameboxcontroller::checkCellModel(cellmodel *rp) {
    this->check(rp);
    if (this->getPl_RemoveList()->size() >= 4) {
        for (int i = 0; i < this->getPl_RemoveList()->size(); i++) {
            cellmodel* p = this->getPl_RemoveList()->getCellModel(i);
            if(this->getPl_RealRemoveList()->judeAddCellModel(p))
                this->getPl_RealRemoveList()->addCellModel(p->getX(), p->getY(), boxGird[p->getX()][p->getY()]);
        }
    }
    this->getPl_RemoveList()->clear();
}
void puyogameboxcontroller::check(cellmodel *rp) {
    this->getPl_RemoveList()->addCellModel(rp->getX(), rp->getY(), boxGird[rp->getX()][rp->getY()]);
    cellmodel* pAround[] = {
        new cellmodel(rp->getX(), rp->getY() - 1),
        new cellmodel(rp->getX() + 1, rp->getY()),
        new cellmodel(rp->getX(), rp->getY() + 1),
        new cellmodel(rp->getX() - 1, rp->getY())
    };
    for (int i = 0; i < 4; i++) {
        if (this->getPl_RemoveList()->judeAddCellModel(pAround[i]) &&
            boxGird[pAround[i]->getX()][pAround[i]->getY()] == boxGird[rp->getX()][rp->getY()]) {
            check(pAround[i]);
        }
    }
}
void puyogameboxcontroller::resetBox() {
    int skip;
    for (int i = 0; i < WIDTH_TOTAL; i++) {
        skip = 0;
        for (int j = HEIGHT_TOTAL - 1; j >= 0; j--) {
            if (boxGird[i][j] == -1) {
                skip++;
            } else if (skip != 0) {
                boxGird[i][j + skip] = boxGird[i][j];
                boxGird[i][j] = -1;
            }
        }
    }
}
puyogameboxcontroller::puyogameboxcontroller(){
    this->setPl_RemoveList(new celllistmodel());
    this->setPl_RealRemoveList(new celllistmodel());
    boxGird = new int*[WIDTH_TOTAL];
    for (int i=0;i<WIDTH_TOTAL;i++) {
        boxGird[i] = new int[HEIGHT_TOTAL];
    }
}
puyogameboxcontroller::~puyogameboxcontroller() {
    delete this->pl_RealRemoveList;
    delete this->pl_RemoveList;
}
