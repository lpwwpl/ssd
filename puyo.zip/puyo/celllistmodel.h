#ifndef CELLLISTMODEL_H
#define CELLLISTMODEL_H
#include "cellmodel.h"
#include <QList>
//celllistmodel class
class celllistmodel: public QList<cellmodel*> {
public:
    celllistmodel();
    void addCellModel(int x, int y, int type);
    bool judeAddCellModel(cellmodel* cell);
    cellmodel* getCellModel(int index);
    cellmodel* getCellModel(int rx, int ry);
    ~celllistmodel();
};
#endif // CELLLISTMODEL_H
