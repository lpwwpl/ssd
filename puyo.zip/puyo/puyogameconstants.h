#ifndef PUYOGAMECONSTANTS_H
#define PUYOGAMECONSTANTS_H

/* Define the point has no puyo. */
const int NO_PUYOACCUPY = -1;

/* puyo state */
const int HORIZONTAL = 0;
const int VERTICAL = 1;

/* Game Panel size */
const int SCREEN_WIDTH = 300;
const int SCREEN_HEIGHT = 520;

/* game girdding size */
const int WIDTH_TOTAL = 6;
const int HEIGHT_TOTAL = 12;

/* imge size: 32*32 */
const int IMG_SIZE = 32;

/* The point which start draw the game board. */
const int BORDER_LT_X = 10;
const int BORDER_LT_Y = 20;
const int BORDER_RT_X = 202;
const int BORDER_RT_Y = 20;
/* A timer which ordain the period of update and redraw images. */
const  int FPS = 100;

#endif // PUYOGAMECONSTANTS_H
