#ifndef PUYOGAMEAPPLICATION_H
#define PUYOGAMEAPPLICATION_H

#include <QMainWindow>

namespace Ui {
class PuyoGameApplication;
}

class PuyoGameApplicaton : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit PuyoGameApplication(QWidget *parent = 0);
    ~PuyoGameApplication();
    
private:
    Ui::PuyoGameApplication *ui;
};

#endif // PUYOGAMEAPPLICATION_H
