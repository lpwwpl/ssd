#ifndef PUYOGAMEBOXCONTROLLER_H
#define PUYOGAMEBOXCONTROLLER_H
#include "puyogameconstants.h"
#include "cellmodel.h"
#include "celllistmodel.h"
class puyogameboxcontroller {
private:
    celllistmodel* pl_RemoveList;
    celllistmodel* pl_RealRemoveList;
    int **boxGird;
public:
    puyogameboxcontroller();
    celllistmodel* getPl_RemoveList() {
        return this->pl_RemoveList;
    }
    celllistmodel* getPl_RealRemoveList() {
        return this->pl_RealRemoveList;
    }
    void setPl_RemoveList(celllistmodel* rpl_RemoveList) {
        this->pl_RemoveList = rpl_RemoveList;
    }
    void setPl_RealRemoveList(celllistmodel* rpl_RealRemoveList) {
        this->pl_RealRemoveList = rpl_RealRemoveList;
    }
    int** getBoxGird() {
        return this->boxGird;
    }
    void clearGrid();
    void addCellModel2Puyo(cellmodel* rp) {
        boxGird[rp->getX()][rp->getY()] = rp->getPtype();
    }
    void removeCellModelFromPuyo();
    void checkBox();
    void checkCellModel(cellmodel* rp);
    void check(cellmodel* rp);
    void resetBox();
    ~puyogameboxcontroller();
};
#endif // PUYOGAMEBOXCONTROLLER_H
