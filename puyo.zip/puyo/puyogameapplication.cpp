#include "puyogameapplication.h"
#include "ui_puyogameapplication.h"

PuyoGameApplication::PuyoGameApplication(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::PuyoGameApplication)
{
    ui->setupUi(this);
}

PuyoGameApplication::~PuyoGameApplication()
{
    delete ui;
}
