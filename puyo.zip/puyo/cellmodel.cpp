#include "cellmodel.h"

cellmodel::cellmodel(void): x(0), y(0),ptype(0) {
}

cellmodel::cellmodel(int x, int y):x(x), y(y) {
}

cellmodel::cellmodel(int x, int y,int ptype):x(x), y(y),ptype(ptype) {
}
cellmodel::~cellmodel() {
}

