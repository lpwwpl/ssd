#include "puyogameui.h"
#include <QString>
#include <Qt>
#include <QByteArray>
#include <QPainter>

void puyogameui::paintEvent(QPaintEvent *e) {
    this->resize(300,520);
    QPainter painter(this);
    painter.setBrush(Qt::black);
    painter.setPen(Qt::white);
    painter.drawRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    painter.drawRect(BORDER_LT_X,BORDER_LT_Y, IMG_SIZE * WIDTH_TOTAL, IMG_SIZE * HEIGHT_TOTAL);
    painter.setPen(QPen(Qt::white));
    QFont f("Arial");
    f.setBold(true);
    f.setWeight(13);
    painter.setFont(f);
    painter.drawText(20, 430,QString::fromUtf8("Please press R to restart if game is over!"));
    painter.drawText(20, 450,QString::fromUtf8("Please press P to pause the game. "));
    painter.drawText(BORDER_RT_X + 20,BORDER_RT_Y,"Next:");
    painter.drawText(BORDER_RT_X + 20,BORDER_RT_Y + 30 + IMG_SIZE,"Scroce:");
    update();
    drawPuyo(&painter);
    painter.setPen(QPen(Qt::darkGray));
    painter.drawText(BORDER_RT_X + 20,BORDER_RT_Y + 50 + IMG_SIZE, QString::number(iscore));
    if (game_Over) {
        f.setWeight(30);
        painter.setFont(f);
        painter.setPen(QPen(Qt::red));
        painter.drawText(40, 200,QString::fromUtf8("Game Over !"));
    }
}

void puyogameui::keyReleaseEvent(QKeyEvent *event) {
    switch(event->key()) {
        case Qt::Key_Down:
            mTimer->setInterval(FPS);
            break;
        default:break;
    }
}

void puyogameui::keyPressEvent(QKeyEvent *event) {
    switch(event->key()) {
        case Qt::Key_Left:
            if (!bstop_1 && !bstop_2 && !flash_Flag && !game_Over) {
                    if(p_puyo1->getX() - 1 >= 0) {
                        if (puyo_State == HORIZONTAL) {
                            if (gameBox->getBoxGird()[p_puyo1->getX() - 1][p_puyo1->getY()] == NO_PUYOACCUPY) {
                                p_puyo1->setX(p_puyo1->getX()-1);
                                p_puyo2->setX(p_puyo2->getX()-1);
                            }
                        } else {
                            if (gameBox->getBoxGird()[p_puyo1->getX() - 1][p_puyo1->getY()] == NO_PUYOACCUPY
                                    && gameBox->getBoxGird()[p_puyo2->getX() - 1][p_puyo2->getY()] == NO_PUYOACCUPY) {
                                p_puyo1->setX(p_puyo1->getX()-1);
                                p_puyo2->setX(p_puyo2->getX()-1);
                            }
                        }
                    }
            }
            break;
        case Qt::Key_Right:
            if (!bstop_1 && !bstop_2 && !flash_Flag && !game_Over) {
                if(puyo_State == HORIZONTAL) {
                    if (p_puyo2->getX() < WIDTH_TOTAL - 1) {
                        if (gameBox->getBoxGird()[p_puyo2->getX() + 1][p_puyo2->getY()] == NO_PUYOACCUPY) {
                            p_puyo1->setX(p_puyo1->getX()+1);
                            p_puyo2->setX(p_puyo2->getX()+1);
                        }
                    }
                } else {
                    if (p_puyo2->getX() < WIDTH_TOTAL - 1) {
                        if (gameBox->getBoxGird()[p_puyo1->getX() + 1][p_puyo1->getY()] == NO_PUYOACCUPY
                                && gameBox->getBoxGird()[p_puyo2->getX() + 1][p_puyo2->getY()] == NO_PUYOACCUPY) {
                            p_puyo1->setX(p_puyo1->getX()+1);
                            p_puyo2->setX(p_puyo2->getX()+1);
                        }
                    }
                }
            }
            break;
        case Qt::Key_Up:
            if (!bstop_1 && !bstop_2 && !flash_Flag && !game_Over) {
                changeState();
            }
            break;
        case Qt::Key_Down:
            if (!bstop_1 && !bstop_2 && !flash_Flag && !game_Over) {
                mTimer->setInterval(FPS / 4);
            }

            break;
        case Qt::Key_P:
            game_Pause = !game_Pause;
            break;
        case Qt::Key_R:
            if (game_Over) {
                initData();
                creatPuyo();
                resetPuyo();
                creatPuyo();
            }
            break;
        default: break;
    }
}

void puyogameui::checkCollide() {
    if (puyo_State == 0
            && p_puyo1->getY() < HEIGHT_TOTAL) {
        if (p_puyo1->getY() == HEIGHT_TOTAL - 1
                || gameBox->getBoxGird()[p_puyo1->getX()][p_puyo1->getY() + 1] != -1) {
            bstop_1 = true;
        }
        if (p_puyo2->getY() == HEIGHT_TOTAL - 1
                || gameBox->getBoxGird()[p_puyo2->getX()][p_puyo2->getY() + 1] != -1) {
            bstop_2 = true;
        }
    } else if (p_puyo1->getY() < HEIGHT_TOTAL) {
        if (p_puyo1->getY() == HEIGHT_TOTAL - 1
                || gameBox->getBoxGird()[p_puyo1->getX()][p_puyo1->getY() + 1] != -1) {
            bstop_1 = true;
            bstop_2 = true;
        }
    }
}

void puyogameui::drawPuyo(QPainter* painter) {
    for (int i = 0; i < WIDTH_TOTAL; i++) {
        for (int j = 0; j < HEIGHT_TOTAL; j++) {
            if (gameBox->getBoxGird()[i][j] != NO_PUYOACCUPY && !bFlashCellModel[i][j]) {
                int target_x = i * IMG_SIZE + BORDER_LT_X;
                int target_y = j * IMG_SIZE + BORDER_LT_Y;
                  painter->drawPixmap(target_x,target_y,32,32,*imageList[gameBox->getBoxGird()[i][j]]);
            }
        }
    }
    /* Show the next turn puyo on top-right of the panel. */
    int target_x = BORDER_RT_X + 20;
    int target_y = BORDER_RT_Y + 10;
    painter->drawPixmap(target_x,target_y,32,32,*imageList[ipre_puyo_1]);

    target_x = BORDER_RT_X + 20 + IMG_SIZE;
    target_y = BORDER_RT_Y + 10;
    painter->drawPixmap(target_x,target_y,32,32, *imageList[ipre_puyo_2]);

    if (p_puyo1->getPtype() != NO_PUYOACCUPY) {
        target_x = p_puyo1->getX() * IMG_SIZE + BORDER_LT_X;
        target_y = p_puyo1->getY() * IMG_SIZE + BORDER_LT_Y;
        painter->drawPixmap(target_x,target_y,32,32,*imageList[p_puyo1->getPtype()]);
    }
    if (p_puyo2->getPtype() != NO_PUYOACCUPY) {
        target_x = p_puyo2->getX() * IMG_SIZE + BORDER_LT_X;
        target_y = p_puyo2->getY() * IMG_SIZE +  BORDER_LT_Y;
        painter->drawPixmap(target_x,target_y,32,32, *imageList[p_puyo2->getPtype()]);
    }
}

void puyogameui::countScore() {
    iscore = 40 + (gameBox->getPl_RealRemoveList()->size() - 4) * 20 + iscore;
}

/* Update function. */
 void puyogameui::update() {
    if (!flash_Flag && !game_Pause && !game_Over) {
        if (gameBox->getPl_RealRemoveList()->size() >= 4) {
            flash_Flag = true;
            return;
        }
        if (gameBox->getBoxGird()[2][0] != NO_PUYOACCUPY
                || gameBox->getBoxGird()[3][0] != NO_PUYOACCUPY) {
            game_Over = true;
            return;
        }
        time_Count = (++time_Count) % 5;
        if (time_Count == 4) {
            if (!bstop_1) {
                p_puyo1->setY(p_puyo1->getY()+1);
            }
            if (!bstop_2) {
                p_puyo2->setY(p_puyo2->getY()+1);
            }
        }
        checkCollide();
        if (bstop_1 && bstop_2) {
            gameBox->addCellModel2Puyo(p_puyo1);
            gameBox->addCellModel2Puyo(p_puyo2);
            gameBox->checkBox();
            resetPuyo();
            creatPuyo();
        }
    } else if (flash_Flag && !game_Pause) {
        if (flash_Count == 0) {
            mTimer->setInterval(FPS);
        }
        flash_Count++;
        flashTurn();
        if (flash_Count > 10) {
            resetFlashGird();
            flash_Count = 0;
            countScore();
            gameBox->removeCellModelFromPuyo();
            gameBox->checkBox();
            flash_Flag = false;
        }
    }
}

void puyogameui::changeState() {
     switch (puyo_State) {
     case 0:
         if (p_puyo1->getY() - 1 >= 0) {
             if (gameBox->getBoxGird()[p_puyo1->getX()][p_puyo1->getY() - 1] == NO_PUYOACCUPY) {
                 p_puyo2->setX(p_puyo2->getX()-1);
                 p_puyo2->setY(p_puyo2->getY()-1);
                 itemptype = p_puyo2->getPtype();
                 p_puyo2->setPtype(p_puyo1->getPtype());
                 p_puyo1->setPtype(itemptype);
                 puyo_State++;
             }
         }
         break;
     case VERTICAL:
         if (p_puyo1->getX() + 1 < WIDTH_TOTAL) {
             if (gameBox->getBoxGird()[p_puyo1->getX() + 1][p_puyo1->getY()] == NO_PUYOACCUPY) {
                 p_puyo2->setX(p_puyo2->getX()+1);
                 p_puyo2->setY(p_puyo2->getY()+1);
                 puyo_State++;
             }
         }
         break;
     }
     puyo_State = puyo_State % 2;
 }

void puyogameui::clearPuyo() {
    p_puyo1->setPtype(NO_PUYOACCUPY);
    p_puyo2->setPtype(NO_PUYOACCUPY);
}

void puyogameui::resetPuyo() {
    bstop_1 = false;
    bstop_2 = false;
    puyo_State = 0;
    p_puyo1->setX(2);
    p_puyo1->setY(0);
    p_puyo1->setPtype(ipre_puyo_1);
    p_puyo2->setX(3);
    p_puyo2->setY(0);
    p_puyo2->setPtype(ipre_puyo_2);
}

void puyogameui::creatPuyo() {
    time = QTime::currentTime();
    qsrand(time.msec()+time.second()*3);
    this->setIpre_puyo_1(qrand()%3);
    this->setIpre_puyo_2(qrand()%3);
}

void puyogameui::initData() {
    iscore = 0;
    game_Over = false;
    game_Pause = false;
    flash_Count = 0;
    flash_Flag = false;
    bstop_1 = false;
    bstop_2 = false;
    time_Count = 0;
    gameBox->clearGrid();
    resetFlashGird();
}

puyogameui::puyogameui() {
    bFlashCellModel = new bool*[WIDTH_TOTAL];
    for(int i=0;i<WIDTH_TOTAL;i++) {
        bFlashCellModel[i] = new bool[HEIGHT_TOTAL];
    }
    p_puyo1 = new cellmodel();
    p_puyo2 = new cellmodel();
    imageList[0]=loadImage(":/res/puyo_blue.png");
    imageList[1]=loadImage(":/res/puyo_green.png");
    imageList[2]=loadImage(":/res/puyo_red.png");
    imageList[3]=loadImage(":/res/puyo_yellow.png");
    gameBox = new puyogameboxcontroller();
    mTimer = new QTimer(this);
    init();
}

QPixmap* puyogameui::loadImage(QString imageName) {
    try {
        QPixmap* img = new QPixmap();
        img->load(imageName);
        return img;
    } catch (...) {

    }
    return NULL;
}

void puyogameui::resetFlashGird() {
    for (int i = 0; i < gameBox->getPl_RealRemoveList()->size(); i++) {
        cellmodel* p = gameBox->getPl_RealRemoveList()->getCellModel(i);
        bFlashCellModel[p->getX()][p->getY()] = false;
    }
}

void puyogameui::flashTurn() {
    for (int i = 0; i < gameBox->getPl_RealRemoveList()->size(); i++) {
        cellmodel* p = gameBox->getPl_RealRemoveList()->getCellModel(i);
        if (flash_Count % 2 == 0) {
            bFlashCellModel[p->getX()][p->getY()] = false;
        } else {
            bFlashCellModel[p->getX()][p->getY()] = true;
        }
    }
}

void puyogameui::init() {
    initData();
    connect(mTimer,SIGNAL(timeout()),this,SLOT(update()));
    mTimer->start(FPS);
    creatPuyo();
    resetPuyo();
    creatPuyo();
}
