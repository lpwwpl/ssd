#include <QtGui/QApplication>
#include "puyogameui.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    puyogameui w;
    w.show();    
    return a.exec();
}
