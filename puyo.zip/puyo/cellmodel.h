#ifndef CELLMODEL_H
#define CELLMODEL_H
class cellmodel {
private:
    int x;
    int y;
    int ptype;
public:
    cellmodel();
    cellmodel(int rx,int ry);
    cellmodel(int rx,int ry,int rptype);
    void setX(int rx) {
        this->x = rx;
    }
    void setY(int ry) {
        this->y = ry;
    }
    void setPtype(int rptype) {
        this->ptype = rptype;
    }
    int getX() {
        return this->x;
    }
    int getY() {
        return this->y;
    }
    int getPtype() {
        return this->ptype;
    }
    ~cellmodel();
};
#endif // CELLMODEL_H
