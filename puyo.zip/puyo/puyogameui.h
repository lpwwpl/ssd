#ifndef PUYOGAMEUI_H
#define PUYOGAMEUI_H
#include <QtGui>
#include <QTimer>
#include <QTime>
#include <QPainter>
#include <QThread>
#include <QPixmap>
#include <QString>
#include <QKeyEvent>
#include "puyogameboxcontroller.h"
#include "celllistmodel.h"
#include "cellmodel.h"
class puyogameui: public QWidget{
    Q_OBJECT
private:
    int ipre_puyo_1;
    int ipre_puyo_2;
    cellmodel* p_puyo1;
    cellmodel* p_puyo2;
    int puyo_State;
    int itemptype;
    int iscore;
    int time_Count;
    int flash_Count;
    bool flash_Flag;
    bool **bFlashCellModel;
    bool bstop_1;
    bool bstop_2;
    bool game_Pause;
    bool game_Over;
    QTime time;
    QTimer* mTimer;
    QPixmap* imageList[4];
    puyogameboxcontroller* gameBox;
public slots:

protected slots:
protected:
    void paintEvent(QPaintEvent* event);
    void keyPressEvent(QKeyEvent *);
    void keyReleaseEvent(QKeyEvent *);
public:
    puyogameui();
    void setIpre_puyo_1(int ripre_puyo_1) {
        this->ipre_puyo_1 = ripre_puyo_1;
    }
    void setIpre_puyo_2(int ripre_puyo_2) {
        this->ipre_puyo_2 = ripre_puyo_2;
    }
    void initData();
    void creatPuyo();
    void resetPuyo();
    void clearPuyo();
    void changeState();
    void update();
    void countScore();
    void flashTurn() ;
    void drawPuyo(QPainter* painter) ;
    void init() ;
    void checkCollide();
    QPixmap* loadImage(QString imageName);
    void resetFlashGird();
};
#endif // PUYOGAMEUI_H
